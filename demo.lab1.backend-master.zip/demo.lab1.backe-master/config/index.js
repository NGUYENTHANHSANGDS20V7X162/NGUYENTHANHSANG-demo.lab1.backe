const config = {
    app: {
        port: 3000,
    },

    db: {
        uri: "mongodb://127.0.0.1:27017/Contactbook-backe",
    }
};

module.exports = config;


